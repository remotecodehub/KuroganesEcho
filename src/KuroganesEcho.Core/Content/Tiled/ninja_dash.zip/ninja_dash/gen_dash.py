"""
Gera Dash.png (esquiva/dash) para cada personagem do pack Ninja da CraftPix.
Usa só os frames originais (Idle e Run) como base e aplica:
  - agachada de antecipação (squash vertical por NEAREST, sem suavizar)
  - inclinação do corpo para frente (shear em degraus de 1 px)
  - imagens residuais (afterimages) tingidas, atrás do personagem
  - linhas de velocidade
Mantém o tamanho de frame original: Kunoichi 128x128, Monk/Peasant 96x96.
"""
import os
import numpy as np
from PIL import Image, ImageDraw

SRC = "/home/claude/ninja"
OUT = "/mnt/user-data/outputs/ninja_dash"

# fs = tamanho do frame | A, B = índices dos frames de Run usados como pose de dash
# k = quanto inclinar para frente (px de deslocamento por px de altura)
CHARS = {
    "Kunoichi":      dict(fs=128, A=2, B=6, k=0.10),
    "Ninja_Monk":    dict(fs=96,  A=6, B=2, k=0.07),
    "Ninja_Peasant": dict(fs=96,  A=2, B=5, k=0.10),
}

TINT = np.array([185, 215, 255], dtype=np.float32)   # azul-gelo das imagens residuais
LINE_RGB = (225, 235, 255)


def get_frame(sheet, i, fs):
    return sheet.crop((i * fs, 0, (i + 1) * fs, fs))


def blit(dst, src, dx=0, dy=0):
    """Composita src sobre dst (arrays RGBA uint8) com recorte e alpha 'over'."""
    h, w = dst.shape[:2]
    sh, sw = src.shape[:2]
    x0, y0 = max(dx, 0), max(dy, 0)
    x1, y1 = min(dx + sw, w), min(dy + sh, h)
    if x0 >= x1 or y0 >= y1:
        return
    s = src[y0 - dy:y1 - dy, x0 - dx:x1 - dx].astype(np.float32)
    d = dst[y0:y1, x0:x1].astype(np.float32)
    sa = s[..., 3:4] / 255.0
    da = d[..., 3:4] / 255.0
    oa = sa + da * (1 - sa)
    rgb = np.where(oa > 0, (s[..., :3] * sa + d[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6), 0)
    dst[y0:y1, x0:x1, :3] = rgb.round().astype(np.uint8)
    dst[y0:y1, x0:x1, 3:4] = (oa * 255).round().astype(np.uint8)


def squash(fr, sy, sx=1.0):
    """Agacha/estica o sprite ancorado nos pés, sem suavização."""
    bb = fr.getbbox()
    spr = fr.crop(bb)
    w, h = spr.size
    nw, nh = max(1, round(w * sx)), max(1, round(h * sy))
    spr = spr.resize((nw, nh), Image.NEAREST)
    out = np.zeros((fr.height, fr.width, 4), np.uint8)
    cx = (bb[0] + bb[2]) // 2
    blit(out, np.array(spr), cx - nw // 2, bb[3] - nh)
    return Image.fromarray(out)


def shear(fr, k):
    """Inclina o corpo para a direita (frente) em degraus de 1 px, ancorado nos pés."""
    a = np.array(fr)
    bb = fr.getbbox()
    bottom = bb[3] - 1
    out = np.zeros_like(a)
    for y in range(bb[1], bb[3]):
        dx = round((bottom - y) * k)
        row = a[y]
        if dx >= 0:
            out[y, dx:] = row[:a.shape[1] - dx] if dx else row
        else:
            out[y, :dx] = row[-dx:]
    return Image.fromarray(out)


def afterimage(fr, alpha):
    a = np.array(fr).astype(np.float32)
    mask = a[..., 3] > 0
    a[..., :3][mask] = a[..., :3][mask] * 0.35 + TINT * 0.65
    a[..., 3][mask] = alpha
    return a.round().astype(np.uint8)


def speed_lines(canvas, fr, specs):
    """specs: lista de (fração da altura, comprimento, alpha). Linha termina atrás do corpo naquela altura."""
    a = np.array(fr)
    bb = fr.getbbox()
    for frac, length, alpha in specs:
        y = bb[1] + int((bb[3] - bb[1]) * frac)
        xs = np.where(a[y, :, 3] > 0)[0]
        if len(xs) == 0:
            continue
        x_end = xs.min() - 3
        x_start = x_end - length
        if x_end < 6:
            continue
        x_start = max(x_start, 0)
        line = np.zeros((1, x_end - x_start, 4), np.uint8)
        line[..., :3] = LINE_RGB
        line[..., 3] = alpha
        blit(canvas, line, x_start, y)


def build_dash(name, cfg):
    fs, A, B, k = cfg["fs"], cfg["A"], cfg["B"], cfg["k"]
    run = Image.open(f"{SRC}/{name}/Run.png").convert("RGBA")
    idle = Image.open(f"{SRC}/{name}/Idle.png").convert("RGBA")
    poseA, poseB = get_frame(run, A, fs), get_frame(run, B, fs)
    idle0 = get_frame(idle, 0, fs)
    step = 8 if fs == 128 else 6   # distância entre imagens residuais

    # (frame base, lean, nº de afterimages, linhas de velocidade)
    L3 = [(0.35, 14, 150), (0.55, 20, 190), (0.75, 12, 130)]
    L2 = [(0.45, 14, 150), (0.68, 10, 120)]
    L1 = [(0.55, 8, 110)]
    plan = [
        ("squash", dict(sy=0.86, sx=1.06), 0, []),
        (poseA, k * 0.6, 1, []),
        (poseB, k,       3, L3),
        (poseA, k,       3, L2),
        (poseB, k,       3, L3),
        (poseA, k * 0.6, 2, L1),
        (poseB, k * 0.3, 1, []),
        ("squash", dict(sy=0.94, sx=1.03), 0, []),
    ]

    frames = []
    for base, p, n_ai, lines in plan:
        if base == "squash":
            main = squash(idle0, **p)
        else:
            main = shear(base, p) if p else base
        canvas = np.zeros((fs, fs, 4), np.uint8)
        alphas = [110, 70, 40]
        for i in range(n_ai, 0, -1):        # mais distante primeiro
            blit(canvas, afterimage(main, alphas[i - 1]), -step * i, 0)
        if lines:
            speed_lines(canvas, main, lines)
        blit(canvas, np.array(main))
        frames.append(Image.fromarray(canvas))

    sheet = Image.new("RGBA", (fs * len(frames), fs), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        sheet.paste(f, (i * fs, 0))
    return sheet, frames


def previews(name, sheet, frames, fs, bg=(70, 90, 110, 255)):
    scale = 4 if fs == 96 else 3
    # GIF animado
    gif_frames = []
    for f in frames:
        bgimg = Image.new("RGBA", f.size, bg)
        bgimg.alpha_composite(f)
        gif_frames.append(bgimg.resize((fs * scale, fs * scale), Image.NEAREST).convert("P", palette=Image.ADAPTIVE))
    gif_frames[0].save(f"{OUT}/{name}/Dash_preview.gif", save_all=True, append_images=gif_frames[1:],
                       duration=80, loop=0, disposal=2)
    # sheet com fundo e numeração
    s2 = Image.new("RGBA", sheet.size, bg)
    s2.alpha_composite(sheet)
    s2 = s2.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST)
    d = ImageDraw.Draw(s2)
    for i in range(len(frames)):
        d.text((i * fs * 2 + 4, 4), str(i), fill=(255, 255, 0, 255))
        d.rectangle((i * fs * 2, 0, (i + 1) * fs * 2 - 1, fs * 2 - 1), outline=(255, 255, 255, 50))
    s2.save(f"{OUT}/{name}/Dash_preview_sheet.png")


if __name__ == "__main__":
    for name, cfg in CHARS.items():
        os.makedirs(f"{OUT}/{name}", exist_ok=True)
        sheet, frames = build_dash(name, cfg)
        sheet.save(f"{OUT}/{name}/Dash.png")
        previews(name, sheet, frames, cfg["fs"])
        print(name, sheet.size, f"{len(frames)} frames de {cfg['fs']}x{cfg['fs']}")
